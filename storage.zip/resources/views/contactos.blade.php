@extends('layout.main-navbar')

@section('contenido')

	<div class='row'>
		<div class='col-md-4 col-md-offset-4'>
			
			<div>
				<h1 id='contenido'>Contactos</h1>
			</div>

		</div>
	</div>

@endsection