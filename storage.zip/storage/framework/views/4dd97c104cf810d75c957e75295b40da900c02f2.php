<!DOCTYPE html>
<html>

	<head>
		<title>Neuronas Reggae</title>
		
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
        <script src="bootstrap/js/jquery.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>

        <!-- jquery ui -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('jquery-ui/jquery-ui.min.css')); ?>">
        <script src="jquery-ui/jquery-ui.min.js"></script>

        <!-- Google font -->
        <link href='https://fonts.googleapis.com/css?family=Indie+Flower|Bangers|Permanent+Marker|Rock+Salt' rel='stylesheet' type='text/css'>

        <!-- styles -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('styles.css')); ?>">
	
        <!-- .ico -->
        <link rel="shortcut icon" href="<?php echo e(asset('NeuronaICO.ico')); ?>">
    </head>

	<body>
        <ul class="nav nav-pills">
            <li role="presentation"><a href="index">Principal</a></li>
            <li role="presentation"><a href="eventos">Eventos</a></li>
            <li role="presentation"><a href="contactos">Contacto</a></li>
        </ul>           

            <?php echo $__env->yieldContent('contenido'); ?>
                    
		<script src="estilosJquery.js"></script>
	</body>

</html>