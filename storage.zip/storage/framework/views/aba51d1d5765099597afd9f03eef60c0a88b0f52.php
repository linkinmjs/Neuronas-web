<?php $__env->startSection('contenido'); ?>

	<?php echo $__env->make('partial/errores', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class='row'>
		<div class='col-md-4 col-md-offset-4'>

			<form id='formGroup' role="form" method='POST' action="<?php echo e(url('eventos')); ?>">
				<?php echo csrf_field(); ?>


				<div>
					<h1 id='subtitulo'>Eventos</h1>
				</div>

				<br>

				<div class="input-group">
					<span class="input-group-addon" id="basic-addon1"><span class='glyphicon glyphicon-bullhorn'></span></span>
					<input name="nombre" type="text" class="form-control" placeholder="Nombre..." aria-describedby="basic-addon1">
				</div>

				<br>

				<div class="input-group">
					<span class="input-group-addon" id="basic-addon1"><span class='glyphicon glyphicon-align-left'></span></span>
					<textarea name="descripcion" class="form-control" rows="10" placeholder="Descripcion..." aria-describedby="basic-addon1"><?php echo e(old('descripcion')); ?></textarea>
				</div>

				<br>

				<div class="input-group">
					<span class="input-group-addon" id="basic-addon1"><span class='glyphicon glyphicon-calendar'></span></span>
					<input name="fecha" id="datepicker" type="text" class="form-control" placeholder="Fecha" aria-describedby="basic-addon1">
					<select class="form-control" name="hora">
					<?php for($i = 0; $i < 25; $i++): ?>
					<option><?php echo e($i); ?> Horas</option>
					<?php endfor; ?>
					</select>
				</div>

				<br>

				<div class="form-group">
					<label for="exampleInputFile">Flyer</label>
					<input type="file" id="exampleInputFile">
					<p class="help-block">Ingrese el archivo formato JPG del evento</p>
				</div>				
				
				<br>

				<button type="submit" class="btn btn-warning">Confirmar evento</button>

			</form>


		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>