	<h1>HERRORES</h1>

	<?php if(! $errors->isEmpty()): ?>
		<div class='alert alert-danger'>
			<p><strong>Oooops!</strong> Por favor corrija los siguientes errores: </p>
			<ul>
				<?php foreach($errors->all() as $error): ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		
	<?php endif; ?>