<?php $__env->startSection('contenido'); ?>
<!-- 	<div>
		<h1 id='titulo'>NEURONAS<small id='subtitulo'> Reggae</small></h1>
	</div> -->
	<div>
		<img id='titulo2' src="images/neurona_font.png">
	</div>

	<div class="container" id='contenido'>
		<div class="row">
			<div class="col-md-8">
				<?php for($i = 0; $i < 100; $i++): ?>
				Hola soy un flyer <?php echo e($i); ?>

				<br>
				<?php endfor; ?>
			</div>			
			<div class="col-md-4">
				<?php for($i = 0; $i < 100; $i++): ?>
				Hola soy una foto <?php echo e($i); ?>

				<br>
				<?php endfor; ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.main-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>