<?php $__env->startSection('contenido'); ?>

	<div class='row'>
		<div class='col-md-4 col-md-offset-4'>
			
			<div>
				<h1 id='contenido'>Contactos</h1>
			</div>

		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>